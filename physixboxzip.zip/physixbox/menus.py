import pygame
import sys
import json
from constants import *
from constants import SCREEN_WIDTH, SCREEN_HEIGHT, DEFAULT_COLOR
from constants import DARK_GRAY
from constants import BUTTON_BORDER_BLUE, BACKGROUND_IMAGE_PATH
from constants import HANDWRITTEN_FONT, SCREEN_WIDTH, SCREEN_HEIGHT, BACKGROUND_COLOR, WHITE, NAVY_BLUE, SKY_BLUE, ROYAL_BLUE, CYAN, PURPLE, RED
import constants

def draw_button(screen, text, font, bg_color, text_color, rect, border_color=None, is_hovered=False, is_clicked=False):
    """Draw a button with hover and click animations, including a shadow."""
    shadow_offset = 5  # Offset for the shadow
    shadow_color = (50, 50, 50)  # Dark gray shadow color

    # Draw the shadow
    shadow_rect = pygame.Rect(rect.x + shadow_offset, rect.y + shadow_offset, rect.width, rect.height)
    pygame.draw.rect(screen, shadow_color, shadow_rect, border_radius=20)

    # Adjust button color for hover and click effects
    if is_clicked:
        bg_color = tuple(max(c - 50, 0) for c in bg_color)  # Darken the background color
    elif is_hovered:
        bg_color = tuple(min(c + 30, 255) for c in bg_color)  # Lighten the background color

    # Draw the button
    pygame.draw.rect(screen, bg_color, rect, border_radius=20)
    if border_color:
        pygame.draw.rect(screen, border_color, rect, width=2, border_radius=20)

    # Draw the button text
    text_surface = font.render(text, True, text_color)
    text_rect = text_surface.get_rect(center=(rect[0] + rect[2] // 2, rect[1] + rect[3] // 2))
    screen.blit(text_surface, text_rect)

def main_menu():
    """Display the main menu."""
    clock = pygame.time.Clock()

    # Load the background image for the main menu
    background_image = pygame.image.load(BACKGROUND_IMAGE_PATH)
    background_image = pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

    # Define buttons (aligned to the right side of the screen)
    button_width = 300
    button_height = 80
    button_gap = 20
    start_y = SCREEN_HEIGHT // 3  # Start higher on the screen
    start_x = SCREEN_WIDTH - button_width - 50  # Align to the right side with padding

    buttons = [
        {"rect": pygame.Rect(start_x, start_y, button_width, button_height), "text": "NEW GAME", "bg_color": NAVY_BLUE, "border_color": BUTTON_BORDER_BLUE},
        {"rect": pygame.Rect(start_x, start_y + (button_height + button_gap), button_width, button_height), "text": "CONTINUE", "bg_color": SKY_BLUE, "border_color": None},
        {"rect": pygame.Rect(start_x, start_y + 2 * (button_height + button_gap), button_width, button_height), "text": "LOAD", "bg_color": ROYAL_BLUE, "border_color": None},
        {"rect": pygame.Rect(start_x, start_y + 3 * (button_height + button_gap), button_width, button_height), "text": "LEVEL MENU", "bg_color": CYAN, "border_color": None},
        {"rect": pygame.Rect(start_x, start_y + 4 * (button_height + button_gap), button_width, button_height), "text": "SETTINGS", "bg_color": PURPLE, "border_color": None},
        {"rect": pygame.Rect(start_x, start_y + 5 * (button_height + button_gap), button_width, button_height), "text": "EXIT", "bg_color": RED, "border_color": None},
    ]

    while True:
        # Draw the background image
        screen.blit(background_image, (0, 0))

        mouse_pos = pygame.mouse.get_pos()
        mouse_pressed = pygame.mouse.get_pressed()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                for button in buttons:
                    if button["rect"].collidepoint(mouse_pos):
                        if button["text"] == "NEW GAME":
                            return "NEW_GAME"
                        elif button["text"] == "CONTINUE":
                            return "CONTINUE"
                        elif button["text"] == "LOAD":
                            return "LOAD"
                        elif button["text"] == "LEVEL MENU":
                            return "LEVEL_MENU"
                        elif button["text"] == "SETTINGS":
                            return "SETTINGS"
                        elif button["text"] == "EXIT":
                            pygame.quit()
                            sys.exit()

        for button in buttons:
            is_hovered = button["rect"].collidepoint(mouse_pos)
            is_clicked = mouse_pressed[0] and is_hovered
            draw_button(screen, button["text"], HANDWRITTEN_FONT, button["bg_color"], WHITE, button["rect"], button["border_color"], is_hovered, is_clicked)

        pygame.display.flip()
        clock.tick(60)

def level_menu(unlocked_levels):
    """Display the level selection menu."""
    clock = pygame.time.Clock()

    # Button dimensions
    button_width = 150
    button_height = 50
    button_gap = 20
    start_x = (SCREEN_WIDTH - (button_width + button_gap) * 5) // 2
    start_y = SCREEN_HEIGHT // 3

    while True:
        screen.fill(BACKGROUND_COLOR)  # Use the constant background color
        title_text = HANDWRITTEN_FONT.render("Level Menu", True, WHITE)
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, 50))

        # Draw level buttons
        buttons = []
        for i in range(1, 51):  # 50 levels
            col = (i - 1) % 5
            row = (i - 1) // 5
            x = start_x + col * (button_width + button_gap)
            y = start_y + row * (button_height + button_gap)
            rect = pygame.Rect(x, y, button_width, button_height)
            buttons.append((rect, i))

            # Check if the level is unlocked
            if i <= unlocked_levels:
                pygame.draw.rect(screen, SKY_BLUE, rect, border_radius=10)
                level_text = HANDWRITTEN_FONT.render(f"Level {i}", True, WHITE)
            else:
                pygame.draw.rect(screen, DARK_GRAY, rect, border_radius=10)
                level_text = HANDWRITTEN_FONT.render(f"Locked", True, WHITE)

            text_rect = level_text.get_rect(center=rect.center)
            screen.blit(level_text, text_rect)

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                for rect, level in buttons:
                    if rect.collidepoint(mouse_pos) and level <= unlocked_levels:
                        return level  # Return the selected level

        pygame.display.flip()
        clock.tick(60)

def retry_menu():
    """Display a retry menu when the player falls too far."""
    clock = pygame.time.Clock()
    font = HANDWRITTEN_FONT  # Use Inkfree.ttf for consistency

    # Define buttons
    retry_button = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 50, 200, 50)
    main_menu_button = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 50, 200, 50)

    while True:
        screen.fill(BACKGROUND_COLOR)  # Use the constant background color
        title_text = font.render("You Fell! Retry?", True, WHITE)
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, SCREEN_HEIGHT // 2 - 150))

        # Draw buttons
        mouse_pos = pygame.mouse.get_pos()
        mouse_pressed = pygame.mouse.get_pressed()

        # Retry button
        retry_hovered = retry_button.collidepoint(mouse_pos)
        draw_button(screen, "Retry", HANDWRITTEN_FONT, NAVY_BLUE, WHITE, retry_button, BUTTON_BORDER_BLUE, retry_hovered, mouse_pressed[0])

        # Main menu button
        main_menu_hovered = main_menu_button.collidepoint(mouse_pos)
        draw_button(screen, "Main Menu", HANDWRITTEN_FONT, PURPLE, WHITE, main_menu_button, BUTTON_BORDER_BLUE, main_menu_hovered, mouse_pressed[0])

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    if retry_button.collidepoint(mouse_pos):
                        return True  # Retry the current level
                    elif main_menu_button.collidepoint(mouse_pos):
                        return False  # Return to the main menu

        pygame.display.flip()
        clock.tick(60)

def settings_menu():
    """Display the settings menu."""
    clock = pygame.time.Clock()

    # Define buttons
    customization_button = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 50, 200, 50)
    back_button = pygame.Rect(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 + 50, 200, 50)

    while True:
        screen.fill(BACKGROUND_COLOR)  # Use the constant background color
        title_text = HANDWRITTEN_FONT.render("Settings", True, WHITE)
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, 100))

        # Draw buttons
        mouse_pos = pygame.mouse.get_pos()
        mouse_pressed = pygame.mouse.get_pressed()

        # Customization button
        customization_hovered = customization_button.collidepoint(mouse_pos)
        draw_button(screen, "Customization", HANDWRITTEN_FONT, NAVY_BLUE, WHITE, customization_button, BUTTON_BORDER_BLUE, customization_hovered, mouse_pressed[0])

        # Back button
        back_hovered = back_button.collidepoint(mouse_pos)
        draw_button(screen, "Back", HANDWRITTEN_FONT, PURPLE, WHITE, back_button, BUTTON_BORDER_BLUE, back_hovered, mouse_pressed[0])

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    if customization_button.collidepoint(mouse_pos):
                        customization_tool()  # Open the customization tool
                    elif back_button.collidepoint(mouse_pos):
                        return  # Go back to the main menu

        pygame.display.flip()
        clock.tick(60)

def customization_tool():
    """Display the customization tool to change cube and bullet colors using Tkinter."""
    import tkinter as tk
    from tkinter import colorchooser

    # Load saved colors or use defaults
    try:
        with open(SAVE_FILE, "r") as file:
            save_data = json.load(file)
            cube_color = tuple(save_data.get("cube_color", RED))
            bullet_color = tuple(save_data.get("bullet_color", WHITE))
    except (FileNotFoundError, KeyError, json.JSONDecodeError):
        cube_color = RED
        bullet_color = WHITE

    # Create a Tkinter window
    root = tk.Tk()
    root.title("Customization Tool")
    root.geometry("400x300")
    root.resizable(False, False)

    # Function to choose a color for the cube
    def choose_cube_color():
        nonlocal cube_color
        color_code = colorchooser.askcolor(title="Choose Cube Color")[0]
        if color_code:
            cube_color = tuple(map(int, color_code))
            cube_color_label.config(bg=_rgb_to_hex(cube_color))

    # Function to choose a color for the bullet
    def choose_bullet_color():
        nonlocal bullet_color
        color_code = colorchooser.askcolor(title="Choose Bullet Color")[0]
        if color_code:
            bullet_color = tuple(map(int, color_code))
            bullet_color_label.config(bg=_rgb_to_hex(bullet_color))

    # Function to save the selected colors
    def save_colors():
        try:
            with open(SAVE_FILE, "r") as file:
                save_data = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            save_data = {}

        save_data["cube_color"] = cube_color
        save_data["bullet_color"] = bullet_color

        with open(SAVE_FILE, "w") as file:
            json.dump(save_data, file)

        root.destroy()  # Close the Tkinter window

    # Helper function to convert RGB to HEX
    def _rgb_to_hex(rgb):
        return f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"

    # Cube color selection
    tk.Label(root, text="Cube Color:", font=("Arial", 14)).pack(pady=10)
    cube_color_label = tk.Label(root, bg=_rgb_to_hex(cube_color), width=20, height=2)
    cube_color_label.pack(pady=5)
    tk.Button(root, text="Choose Cube Color", command=choose_cube_color).pack(pady=5)

    # Bullet color selection
    tk.Label(root, text="Bullet Color:", font=("Arial", 14)).pack(pady=10)
    bullet_color_label = tk.Label(root, bg=_rgb_to_hex(bullet_color), width=20, height=2)
    bullet_color_label.pack(pady=5)
    tk.Button(root, text="Choose Bullet Color", command=choose_bullet_color).pack(pady=5)

    # Save button
    tk.Button(root, text="Save and Exit", command=save_colors, bg="green", fg="white").pack(pady=20)

    # Run the Tkinter main loop
    root.mainloop()

def color_picker():
    """Open a color picker dialog to select a color."""
    import tkinter as tk
    from tkinter import colorchooser

    # Pause pygame while using tkinter
    pygame.display.iconify()  # Minimize the pygame window
    root = tk.Tk()
    root.withdraw()  # Hide the root window
    color_code = colorchooser.askcolor(title="Choose a color")[0]  # Returns (R, G, B)
    root.destroy()  # Destroy the tkinter root window
    pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))  # Restore pygame window

    if color_code:
        return tuple(map(int, color_code))  # Convert to integer RGB tuple
    return DEFAULT_COLOR  # Use the imported constant directly