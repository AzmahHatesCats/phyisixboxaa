import pygame
import sys
import json  # For saving and loading progress
from constants import *
from menus import main_menu, level_menu, retry_menu, settings_menu  # Import settings_menu
from level import Level
from player import Player
from bullet import Bullet

SAVE_FILE = "save_data.json"  # File to store progress

def save_progress(current_level, unlocked_levels):
    """Save the current level and unlocked levels to a file."""
    save_data = {
        "current_level": current_level,
        "unlocked_levels": unlocked_levels
    }
    with open(SAVE_FILE, "w") as file:
        json.dump(save_data, file)

def load_progress():
    """Load the saved progress from a file."""
    try:
        with open(SAVE_FILE, "r") as file:
            save_data = json.load(file)
            return save_data["current_level"], save_data["unlocked_levels"]
    except (FileNotFoundError, KeyError, json.JSONDecodeError):
        # If the save file doesn't exist or is corrupted, start fresh
        return 0, 1  # Default to level 1 unlocked

def load_save_file():
    """Display a file selection menu to load a save file."""
    import tkinter as tk
    from tkinter import filedialog

    # Use Tkinter to open a file dialog
    root = tk.Tk()
    root.withdraw()  # Hide the root window
    file_path = filedialog.askopenfilename(
        title="Select Save File",
        filetypes=[("JSON Files", "*.json"), ("All Files", "*.*")]
    )
    root.destroy()  # Destroy the tkinter root window

    if file_path:
        try:
            with open(file_path, "r") as file:
                save_data = json.load(file)
                return save_data["current_level"], save_data["unlocked_levels"]
        except (FileNotFoundError, KeyError, json.JSONDecodeError):
            print("Invalid save file.")
    return None, None  # Return None if no file is selected or invalid

def main():
    pygame.init()
    clock = pygame.time.Clock()

    # Load saved colors
    try:
        with open(SAVE_FILE, "r") as file:
            save_data = json.load(file)
            cube_color = tuple(save_data.get("cube_color", RED))
            bullet_color = tuple(save_data.get("bullet_color", WHITE))
    except (FileNotFoundError, KeyError, json.JSONDecodeError):
        cube_color = RED
        bullet_color = WHITE

    # Initialize player and bullets
    player = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 100)
    bullets = []

    # Load progress
    current_level, unlocked_levels = load_progress()

    # Initialize the first level dynamically
    levels = [Level(1)]  # Start with the first level

    while True:
        # Show the main menu and get the selected action
        menu_action = main_menu()
        if menu_action == "NEW_GAME":
            # Start a new game
            current_level = 0
            unlocked_levels = 1
            levels = [Level(1)]  # Reset levels to start fresh
            run_game(player, bullets, levels, current_level, unlocked_levels, bullet_color)
        elif menu_action == "CONTINUE":
            # Continue from saved progress
            run_game(player, bullets, levels, current_level, unlocked_levels, bullet_color)
        elif menu_action == "LOAD":
            # Load a save file
            loaded_level, loaded_unlocked = load_save_file()
            if loaded_level is not None and loaded_unlocked is not None:
                current_level = loaded_level
                unlocked_levels = loaded_unlocked
                levels = [Level(i + 1) for i in range(current_level + 1)]  # Generate levels up to the current level
                run_game(player, bullets, levels, current_level, unlocked_levels, bullet_color)
            else:
                print("No valid save file selected or file is invalid.")
        elif menu_action == "LEVEL_MENU":
            # Open the level menu and select a level
            selected_level = level_menu(unlocked_levels)
            if selected_level is not None:
                current_level = selected_level - 1  # Convert to 0-based index
                run_game(player, bullets, levels, current_level, unlocked_levels, bullet_color)
        elif menu_action == "SETTINGS":
            # Open the settings menu
            settings_menu()
        elif menu_action == "EXIT":
            pygame.quit()
            sys.exit()

def run_game(player, bullets, levels, current_level, unlocked_levels, bullet_color):
    """Run the game loop for the current level."""
    clock = pygame.time.Clock()
    running = True

    # Load the home icon
    home_icon = pygame.image.load("assets/images/home.png")
    home_icon = pygame.transform.scale(home_icon, (50, 50))

    # Spawn the player on the topmost platform
    spawn_x, spawn_y = levels[current_level].get_spawn_position()
    player.reset(spawn_x, spawn_y)

    while running:
        dt = clock.tick(60) / 1000  # Delta time in seconds

        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                # Save progress before quitting
                save_progress(current_level, unlocked_levels)
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    player.shoot(pygame.mouse.get_pos(), bullets)

        # Update game objects
        player.update(dt, levels[current_level].platforms)
        for bullet in bullets:
            bullet.update()

        # Check if the player falls below the screen
        if player.y > SCREEN_HEIGHT + 200:  # If the player falls too far
            retry = retry_menu()
            if retry:
                # Retry the current level
                spawn_x, spawn_y = levels[current_level].get_spawn_position()
                player.reset(spawn_x, spawn_y)
                bullets.clear()
            else:
                # Save progress and exit to the main menu
                save_progress(current_level, unlocked_levels)
                return

        # Check level completion
        levels[current_level].check_completion(player)
        if levels[current_level].completed:
            unlocked_levels = max(unlocked_levels, current_level + 2)  # Unlock the next level
            current_level += 1

            # Dynamically generate a new level if it doesn't exist
            if current_level >= len(levels):
                levels.append(Level(current_level + 1))  # Create a new level dynamically

            # Reset player and bullets for the next level
            spawn_x, spawn_y = levels[current_level].get_spawn_position()
            player.reset(spawn_x, spawn_y)
            bullets.clear()

        # Draw everything
        screen.fill(BACKGROUND_COLOR)  # Use the constant background color
        levels[current_level].draw()
        player.draw()
        for bullet in bullets:
            bullet.draw(screen)

        # Draw level counter
        level_counter_text = HANDWRITTEN_FONT.render(f"Level: {current_level + 1}", True, WHITE)
        screen.blit(level_counter_text, (SCREEN_WIDTH - level_counter_text.get_width() - 20, 20))

        # Draw home icon
        home_icon_rect = pygame.Rect(10, 10, 50, 50)
        screen.blit(home_icon, home_icon_rect.topleft)
        if home_icon_rect.collidepoint(pygame.mouse.get_pos()) and pygame.mouse.get_pressed()[0]:
            # Save progress and return to the main menu
            save_progress(current_level, unlocked_levels)
            return

        pygame.display.flip()

if __name__ == "__main__":
    main()