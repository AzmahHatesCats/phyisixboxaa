pip install pygame pymunk pybullet numpy matplotlib random
